﻿using AuthLibrary.Context;
using AuthLibrary.Models;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using System.Text;

namespace AuthLibrary;

public class AuthService(AuthContext context)
{
    private readonly AuthContext _context = context;

    private string HashPassword(string password)
    {
        using var sha256 = SHA256.Create();
        var bytes = Encoding.UTF8.GetBytes(password);
        var hash = sha256.ComputeHash(bytes);
        return Convert.ToBase64String(hash);
    }

    public bool Register(string login, string password)
    {
        if (_context.CinemaUsers.Any(u => u.Login == login))
            return false;

        var user = new CinemaUser
        {
            Login = login,
            PasswordHash = HashPassword(password),
            RoleId = _context.CinemaUserRoles.First(r => r.RoleName == "Посетитель").Id,
            FailedLoginAttempts = 0
        };

        _context.CinemaUsers.Add(user);
        _context.SaveChanges();
        return true;
    }

    public CinemaUser? Authenticate(string login, string password)
    {
        var user = _context.CinemaUsers
            .Include(u => u.Role)
            .FirstOrDefault(u => u.Login == login);

        if (user == null)
            return null;

        if (user.UnlockDate.HasValue && user.UnlockDate > DateTime.UtcNow)
            return null;

        if (user.PasswordHash == HashPassword(password))
        {
            user.FailedLoginAttempts = 0;
            user.UnlockDate = null;
            _context.SaveChanges();
            return user;
        }

        user.FailedLoginAttempts++;
        if (user.FailedLoginAttempts >= 3)
            user.UnlockDate = DateTime.UtcNow.AddMinutes(1);
        _context.SaveChanges();
        return null;
    }


    public string? GetUserRole(string login)
    {
        return _context.CinemaUsers
            .Include(u => u.Role)
            .FirstOrDefault(u => u.Login == login)?
            .Role?.RoleName;
    }

    public List<string>? GetUserPrivileges(string login)
    {
        var user = _context.CinemaUsers
            .Include(u => u.Role)
            .ThenInclude(r => r.RolePrivileges)
            .ThenInclude(rp => rp.Privilege)
            .FirstOrDefault(u => u.Login == login);

        return user?.Role.RolePrivileges
            .Select(rp => rp.Privilege.Name)
            .ToList();
    }

    public List<string>? GetRolePrivileges(string roleName)
    {
        var role = _context.CinemaUserRoles
            .Include(r => r.RolePrivileges)
            .ThenInclude(rp => rp.Privilege)
            .FirstOrDefault(r => r.RoleName == roleName);

        return role?.RolePrivileges
            .Select(rp => rp.Privilege.Name)
            .ToList();
    }
}