﻿using AuthLibrary.Models;
using Microsoft.EntityFrameworkCore;

namespace AuthLibrary.Context;

public class AuthContext : DbContext
{
    public DbSet<CinemaUser> CinemaUsers { get; set; }
    public DbSet<CinemaUserRole> CinemaUserRoles { get; set; }
    public DbSet<CinemaPrivilege> CinemaPrivileges { get; set; }
    public DbSet<CinemaRolePrivilege> CinemaRolePrivileges { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlServer("Data Source=mssql;Initial Catalog=ispp3410;User ID=ispp3410;Password=3410;Encrypt=True;Trust Server Certificate=True");
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<CinemaRolePrivilege>()
            .HasKey(rp => new { rp.RoleId, rp.PrivilegeId });
    }
}