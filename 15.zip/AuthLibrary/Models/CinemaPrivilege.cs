﻿using System.ComponentModel.DataAnnotations.Schema;

namespace AuthLibrary.Models;

[Table("CinemaPrivilege")]
public class CinemaPrivilege
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
    public ICollection<CinemaRolePrivilege> RolePrivileges { get; set; } = new List<CinemaRolePrivilege>();
}
