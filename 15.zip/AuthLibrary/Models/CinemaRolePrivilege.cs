﻿using System.ComponentModel.DataAnnotations.Schema;

namespace AuthLibrary.Models;

[Table("CinemaRolePrivilege")]
public class CinemaRolePrivilege
{
    public int RoleId { get; set; }
    public int PrivilegeId { get; set; }
    public CinemaUserRole Role { get; set; } = null!;
    public CinemaPrivilege Privilege { get; set; } = null!;
}
