﻿using System.ComponentModel.DataAnnotations.Schema;

namespace AuthLibrary.Models;

[Table("CinemaUser")]
public class CinemaUser
{
    public int Id { get; set; }
    public string Login { get; set; } = null!;
    public string PasswordHash { get; set; } = null!;
    public int FailedLoginAttempts { get; set; } = 0;
    public DateTime? UnlockDate { get; set; }
    public int RoleId { get; set; }
    public CinemaUserRole Role { get; set; } = null!;
}
