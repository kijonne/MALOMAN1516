﻿using System.ComponentModel.DataAnnotations.Schema;

namespace AuthLibrary.Models;

[Table("CinemaUserRole")]
public class CinemaUserRole
{
    public int Id { get; set; }
    public string RoleName { get; set; } = null!;
    public ICollection<CinemaUser> Users { get; set; } = new List<CinemaUser>();
    public ICollection<CinemaRolePrivilege> RolePrivileges { get; set; } = new List<CinemaRolePrivilege>();
}
