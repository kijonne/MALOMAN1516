﻿using AuthLibrary.Models;

namespace AuthLibrary;

public class UserSession
{
    private static readonly UserSession _session = new();
    private UserSession() { }
    public static UserSession Session => _session;

    public CinemaUser? CurrentUser { get; private set; }

    public void SetCurrentUser(CinemaUser user)
    {
        CurrentUser = user;
    }

    public void Clear()
    {
        CurrentUser = null;
    }
}
