﻿using AuthLibrary.Contexts;
using AuthLibrary.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

public class AuthService(AuthContext context)
{
    private readonly AuthContext _context = context;

    private string HashPassword(string password)
    {
        using var sha256 = SHA256.Create();
        var bytes = Encoding.UTF8.GetBytes(password);
        var hash = sha256.ComputeHash(bytes);
        return Convert.ToBase64String(hash);
    }

    public bool Register(string login, string password)
    {
        if (_context.CinemaUsers.Any(u => u.Login == login))
            return false;

        var user = new CinemaUser
        {
            Login = login,
            PasswordHash = HashPassword(password),
            IncorrectPasswordAttempts = 0,
            RoleId = 3
        };

        _context.CinemaUsers.Add(user);
        _context.SaveChanges();
        return true;
    }

    public CinemaUser Authenticate(string login, string password)
    {
        var user = _context.CinemaUsers
            .Include(u => u.Role)
            .FirstOrDefault(u => u.Login == login);

        if (user == null) return null;

        if (user.UnblockDate.HasValue && user.UnblockDate > DateTime.Now)
            return null;

        if (user.PasswordHash == HashPassword(password))
        {
            user.IncorrectPasswordAttempts = 0;
            _context.SaveChanges();
            return user;
        }
        else
        {
            user.IncorrectPasswordAttempts++;

            if (user.IncorrectPasswordAttempts >= 3)
                user.UnblockDate = DateTime.Now.AddMinutes(1);

            _context.SaveChanges();
            return null;
        }
    }

    public string GetUserRole(string login)
    {
        var user = _context.CinemaUsers
            .Include(u => u.Role)
            .FirstOrDefault(u => u.Login == login);
        return user?.Role?.Name;
    }

    public List<string> GetUserPrivileges(string login)
    {
        var roleId = _context.CinemaUsers
            .Where(u => u.Login == login)
            .Select(u => u.RoleId)
            .FirstOrDefault();

        return _context.CinemaRolePrivileges
            .Where(rp => rp.RoleId == roleId)
            .Include(rp => rp.Privilege)
            .Select(rp => rp.Privilege.Title)
            .ToList();
    }

    public List<string> GetPrivilegesByRole(string roleName)
    {
        var roleId = _context.CinemaUserRoles
            .Where(r => r.Name == roleName) 
            .Select(r => r.Id)
            .FirstOrDefault();

        return _context.CinemaRolePrivileges
            .Where(rp => rp.RoleId == roleId)
            .Include(rp => rp.Privilege)
            .Select(rp => rp.Privilege.Title)
            .ToList();
    }

    public List<CinemaUserRole> GetAllRoles()
    {
        return _context.CinemaUserRoles.ToList();
    }

    public List<CinemaUser> GetAllUsers()
    {
        return _context.CinemaUsers
            .Include(u => u.Role)
            .ToList();
    }

    public bool ChangeUserRole(int userId, int newRoleId)
    {
        var user = _context.CinemaUsers.Find(userId);
        if (user == null) return false;

        user.RoleId = newRoleId;
        _context.SaveChanges();
        return true;
    }

    public CinemaUser GetUserById(int userId) 
        => _context.CinemaUsers
            .Include(u => u.Role)
            .FirstOrDefault(u => u.Id == userId);
}