﻿using System;
using System.Collections.Generic;
using AuthLibrary.Models;
using Microsoft.EntityFrameworkCore;

namespace AuthLibrary.Contexts;

public partial class AuthContext : DbContext
{
    public AuthContext()
    {
    }

    public AuthContext(DbContextOptions<AuthContext> options)
        : base(options)
    {
    }

    public virtual DbSet<CinemaPrivilege> CinemaPrivileges { get; set; }

    public virtual DbSet<CinemaUser> CinemaUsers { get; set; }

    public virtual DbSet<CinemaUserRole> CinemaUserRoles { get; set; }

    public virtual DbSet<CinemaRolePrivilege> CinemaRolePrivileges { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseSqlServer("Data Source=mssql;Initial Catalog=ispp3110; Persist Security Info=True;User ID=ispp3110; Password=3110;Encrypt=True;Trust Server Certificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<CinemaPrivilege>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_CinemaPrivelege");

            entity.ToTable("CinemaPrivilege");

            entity.Property(e => e.Title).HasMaxLength(100);

            entity.HasMany(d => d.Roles).WithMany(p => p.Privileges)
                .UsingEntity<Dictionary<string, object>>(
                    "CinemaRolePrivilege",
                    r => r.HasOne<CinemaUserRole>().WithMany()
                        .HasForeignKey("RoleId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK_CinemaRolePrivilege_CinemaUserRole"),
                    l => l.HasOne<CinemaPrivilege>().WithMany()
                        .HasForeignKey("PrivilegeId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK_CinemaRolePrivilege_CinemaPrivilege"),
                    j =>
                    {
                        j.HasKey("PrivilegeId", "RoleId");
                        j.ToTable("CinemaRolePrivilege");
                    });
        });

        modelBuilder.Entity<CinemaUser>(entity =>
        {
            entity.ToTable("CinemaUser");

            entity.Property(e => e.Login).HasMaxLength(50);
            entity.Property(e => e.PasswordHash).HasMaxLength(200);

            entity.HasOne(d => d.Role).WithMany(p => p.CinemaUsers)
                .HasForeignKey(d => d.RoleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_CinemaUser_CinemaUserRole");
        });

        modelBuilder.Entity<CinemaUserRole>(entity =>
        {
            entity.ToTable("CinemaUserRole");

            entity.Property(e => e.Name).HasMaxLength(20);
        });

        modelBuilder.Entity<CinemaRolePrivilege>(entity =>
        {
            entity.HasKey(e => new { e.PrivilegeId, e.RoleId });

            entity.ToTable("CinemaRolePrivilege");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
