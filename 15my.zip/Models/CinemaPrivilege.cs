﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace AuthLibrary.Models;

[Table("CinemaPrivilege")]
public partial class CinemaPrivilege
{
    public int Id { get; set; }

    public string Title { get; set; }

    public virtual ICollection<CinemaRolePrivilege> Privileges { get; set; } = new List<CinemaRolePrivilege>();
}
