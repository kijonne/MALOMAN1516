﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace AuthLibrary.Models;

[Table("CinemaRolePrivilege")]
public partial class CinemaRolePrivilege
{
    public int PrivilegeId { get; set; }

    public int RoleId { get; set; }

    public CinemaUserRole Role { get; set; } = null!;
    public CinemaPrivilege Privilege { get; set; } = null!;
}
