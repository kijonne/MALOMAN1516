﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace AuthLibrary.Models;

[Table("CinemaUser")]
public partial class CinemaUser
{
    public int Id { get; set; }

    public string Login { get; set; } = null!;

    public string PasswordHash { get; set; } = null!;

    public int IncorrectPasswordAttempts { get; set; }

    public DateTime? UnblockDate { get; set; }

    public int RoleId { get; set; }

    public virtual CinemaUserRole Role { get; set; } = null!;
}
