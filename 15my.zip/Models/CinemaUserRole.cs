﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace AuthLibrary.Models;

[Table("CinemaUserRole")]
public partial class CinemaUserRole
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public virtual ICollection<CinemaUser> CinemaUsers { get; set; } = new List<CinemaUser>();

    public virtual ICollection<CinemaRolePrivilege> Privileges { get; set; } = new List<CinemaRolePrivilege>();
}
